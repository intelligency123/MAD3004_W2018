//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
func factorial(_ n: Int) -> Int {
    if n == 0 {
        return 1
    }
    else {
        return n * factorial(n - 1)
    }
}

print( factorial(20) )
