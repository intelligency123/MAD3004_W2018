//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var a = 14
var l = 1
if (a < 14)
{
    for i in 1...5{
        l = 5*i
        print ("5" ,"*" ,i,"=",l)
    }
    Else {
        for i in 1...5 {
            a *= i
            print ("factorial is" , l)
        }
    }
}

