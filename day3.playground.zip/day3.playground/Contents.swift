//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//error can't assign nil value to string
//var name = (String)
//name = " "
//print (name)
// dictonaries
var nameofintegers = [Int : String] ()// nameofdictionary is an empty [int : string] dictionary
nameofintegers[16] = "sixteen" // nameofintegers now contains 1 key-value pair
print ("nameofintegers : \(nameofintegers)")
nameofintegers[28] = "twenty eight"
print ("dictionary contains \(nameofintegers.count) elements")
print ("dictionar :" , nameofintegers)
nameofintegers = [:] // nameofintegres is once again an empty dictionary of [:] type [int : string]
print ("dictionary contains \(nameofintegers.count) elements")
print ("nameofintegers :",nameofintegers)
if  nameofintegers.isEmpty {
    print ("dictionary is empty")
}
else{
    print(nameofintegers)
}
// dictionary airport with values
var airport : [String : String] = ["xxx" : "toronto pearson","EMP" : "dublin"]
print ("airport : \(airport)")
print ("the airport contains \(airport.count) items")
// print "the airpot dictionary contains 2 items"
airport["LHR"] = "london herthrow" //the value for "lhr"has been changed to "london herthrow"
airport["xxx"] = "TP international"
airport["AMD"] = "SVP international"
print ("airport :",airport)
let oldvalue = airport.updateValue("dublin airport", forKey : "EMP")
print("THE OLDvalue for EMP was \(oldvalue)")
// prints "the old value for emp was dublin" (if it shows error(if value is nil) write it with if condition)
if let airportname = airport["AMD"] {
    print ("the name of the airport is \(airportname).")
}
else {
    print ("that airport is not in the airport dictionary")
}
airport["mars"] = "range rover" //"range rover " is not the real airpot for mars ,so delete it
airport["mars"] = nil //mars airport delete
print ("airport : \(airport)")
if let removevalue = airport.removeValue(forKey : "EMP"){
    print ("the removed airport name is \(removevalue)")
}
else{
    print("the airport dictionary does not contain a value for EMP")
}
// print "the removed airport name is dublin airport"
for (airportcode,airportname) in airport {
    print (airportcode, airportname)
}
for airportcode in airport.keys {
    print ("airportcode : \(airportcode)")
}
for airportname in airport.values {
    print("airportname : \(airportname)")
}
let airportcode = [String] (airport.keys) // airportcodes is ["xxx" ,"LHR"]
print("airportcode : \(airportcode)")
let airportname = [String] (airport.values) // airportname is ["toronto","london herthrew"]
print("airportname : \(airportname)")
// <KEY,VALUES> pairs
var d1 : Dictionary<String , String> = ["india" : "hindi" ,"canada" : "english"]
print (d1)
print(d1.description)
print(d1["india"]!)
print(d1["canada"]!)
print(d1["USA"]) //print nil
d1["china"] = "mandarin"
for(k,v) in d1{
    print("\(k) -> \(v)")
}
d1["canada"] = "french"
for (k,v) in d1 {
    print ("\(k) -> \(v)")
}
var d2 = ["india" : "hindi" ,"canada" : "english"]
for(k,v) in d2 {
    print("\(k) -> \(v)")
}
// dictionary with any valus type
var d3 = [String : AnyObject]()
d3["firstname"] = "jk" as AnyObject
d3["lastname"] = "patel" as AnyObject
d3["age"] = Int(50) as AnyObject
d3["salary"] = nil
print ("d3:",d3)
//getting as a key , value pair
for(k,v) in d3 {
    print ("\(k) -> \(v)")
}
// getting as a single object
for obj in d3{
    print("\(obj.key) -> \(obj.value)")
}
// declaring tuples
var x = (10,20,"patel")
print (x.0)
print(x.1)
print(x.2)
let http404error = (404, "not found")
print(http404error)
let (statuscode, statusmessage) = http404error
print("statuscode : \(statuscode)")
print("statusmessage : \(statusmessage)")
let(codeonly,_) = http404error // if want to print only one part write next one with _
print ("codeonly : \(codeonly)")
let errordescription = (code : 404 , message : "not found")
print (errordescription.code , errordescription.message)
// working with functions

//simple declaration
func add()
{
    print("i am in user defined function")
}
add()
func add(n1:Int , n2:Int) {
    var sum : Int
    sum = n1+n2
    print("sum :",sum)
}
add(n1:10,n2:20)
//add(10,20) //error
//add(n2:30,n1:40) //error n2 must proceed n1
 //single parameter
func welcome(name : String)
{
    print("hello ,\(name)")
}
welcome(name : "kamal")
// making parameter label optional using _
func sub(a:Int , _ b:Int)
{
    let c = a - b
    print("sub : \(c)")
}
sub(a: 30, 20)
// single return value
func mul(a : Int , b :Int) -> Int
{
    var c = a * b
    print ("mul : \(c)")
    return (c)
}
var mulres = mul(a:3 , b:4)
// multi value return
func swipe (number1 a : Int,b: Int) -> (Int,Int)
{
    // function parameters are contants by default
    //var temp = a
    //a = b
   // b = temp
    return(b,a)
}
var(a,b) = swipe(number1: 10,b : 20)
print("a : \(a) , b:\(b)")
var (_,c) = swipe(number1:10, b:20)
print("c : \(c)")

//inout concept
func swipe(aa: inout Double , bb: inout Double)
{
    let temp = aa
    aa = bb
    bb = temp
}
var x1 = 8.0 , y = 9.0
swipe(aa: &x1 , bb: &y)
//swipe(aa:&10,bb:&20) // error can't pass the value directly
print("x : \(x1) , y : \(y)")
// default parameter
func simpleinterest(amount : Double , noofyears :Double, rate : Double = 5.0) -> Double
{
    let si = amount * rate * noofyears / 100
    return si
}
print("simple interest : \(simpleinterest(amount : 1000 , noofyears : 5))")
print ("simple interest : \(simpleinterest(amount : 1000, noofyears:5,rate : 10))")
func si(amount : Double , _ noofyears :Double, rate : Double = 5.0) -> Double
{
    let si1 = amount * rate * noofyears / 100
    return si1
}
print("simple interest : \(simpleinterest(amount : 1000 , noofyears : 5))")
print ("simple interest : \(simpleinterest(amount : 1000, noofyears:5,rate : 10))")
// variadic paramter
func display(n:Int...) // assign type but not value range we can decide that when passing values
{
    for i in n {
        print(i)
    }
}
display(n : 1,2,3,4,5)
display(n: 10,20,30)
// passing array as parameter
func display(numbervalues : Int , parameter : [Int]...)
{
    print("number of values \(numbervalues)")
    for i in parameter {
        print("i : \(i)")
    }
}
var arr = [1,2,3,4,5]
display(numbervalues:3,parameter :arr,arr,arr)
// sum of two arrays
func display(arraylist :[Int]...) -> [Int]
{
    var array1 = arraylist[0]
    var array2 = arraylist[1]
    var result = [Int]()
    if array1.count == array2.count
    {
        for i in 0..<array1.count
        {
            result.append(array1[i] + array2[i])
        }
    }
    return result
}
var a1 = [1,2,3,4,5]
var a2 = [10,11,12,13,14]
var a3 = display(arraylist : a1, a2)
print(a1)
print(a2)
print (a3)
