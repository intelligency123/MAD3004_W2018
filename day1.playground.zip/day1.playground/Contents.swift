//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print(str)
print("this is our string:\(str)",terminator: " ")
// use separator for separating multiple prompts
print("1","2","3","4","5",separator: "..")

var n1 = 10
print("number 1 :",n1,"string :",str)
var n2 = 20
print("number :",n2)
var sum = n1+n2
print("sum is:",sum)
print("sum =",n1+n2)

/*
n1 ="test"
print("n1 : ",n1)
 */

var a:Int = 10
print("a =",a)

var greet:String = "good morning"
print("greeting : ",greet)

var emoji = "😀"
print ("its a \(emoji) hour")
// use ctrl+cmd+space to include emoji on mac

let pi = 3.14
print ("pi =",pi)
// optional values
let mynum: Int?
//mynum = 10
mynum = nil
if mynum != nil {
    print ("mynum : " ,mynum!)
}
else {
    print ("mynum is nil")

    // optional values
    let possiblenumber  = "hello"
    let convertednumber:Int?
    
    convertednumber = Int(possiblenumber)
    if convertednumber != nil {
        print ("converted number" , convertednumber!)
    }
    else{
        print ("converted number is nil")
    }
    for i in 1..<5 {
        print ("i =",i)
    
    }
    
    let languages:[String]
    languages = ["english" , "spanish", "french"]
    for i in languages {
        print ("language : " , i)
}
}
var answer :Int = 1
for _ in 1...5 {
    answer *= 5;
}
print ("answer =" ,answer)

var interval :Int = 5
for i in stride( from :0, to: 50, by: interval){
    print (i,"",terminator: "")
}
var j = 1
while (j < 5) {
    print ("value of j is \(j)")
    j = j+1
}

j = 5
repeat{
    print ("repeat :", j)
    j = j+2
}while (j<=10)




var num1 = 100
switch num1 {
case 100 :
    print ("value of num1 is 100")
    fallthrough
case 10,15 :
    print ("value of num1 is either 10 or 15")
case 5 :
    print ("value of num1 is 5")
default :
    print ("default case")
}
let countedthings = "moons orbiting saturn"
let naturalcount: String
switch approximatecount {
case 0:
    naturalcount ="no"
}
var a = 14
var l = 1
if (a <14)
{
    for i in 1...5{
        l = 5*i
        print ("a" ,"*" ,i,"=",l)
    }
    else{
        for i in 1...5 {
            a *=i
            print ("factorial is" , l)
        }
    }
}

