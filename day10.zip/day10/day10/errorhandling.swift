//
//  errorhandling.swift
//  day10
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


enum limitincreaseerror : Error{
    case insuffucientbalance(balanceneeded : Double)
    case nosavingaccount
    case ineligible
    case processapproved
}

struct requestsfromaccount{
    var type : String
    var balance : Double
    var reqstatus : String
}
