//
//  requesterror.swift
//  day10
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class requestlimitincrease{
    var requestreceived = [
        "S1100" : requestsfromaccount(type : "saving" , balance : 1234.09, reqstatus : "in process"),
        "S1200" : requestsfromaccount(type : "saving", balance : 5080.09 , reqstatus: "in process"),
        "S1300" : requestsfromaccount(type : "chequing",balance : 10000.09,reqstatus : "in process"),
        "S1400" : requestsfromaccount(type : "saving",balance: 5400 , reqstatus : "approved")
    ]
    
    func increaselimit(accountno acno: String) throws {
        guard let reqacc = requestreceived[acno] else {
            throw limitincreaseerror.ineligible
        }
        guard reqacc.type == "saving" else{
            throw limitincreaseerror.nosavingaccount
        }
        guard reqacc.balance >= 5000 else{
            throw limitincreaseerror.insuffucientbalance(balanceneeded: 5000 - reqacc.balance)
        }
        guard reqacc.reqstatus == "in process" else{
            throw limitincreaseerror.processapproved
        }
        var approvedrequest = reqacc
        approvedrequest.reqstatus = "approved"
        print("your request is approved")
    }
    
}
