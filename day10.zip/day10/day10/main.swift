//
//  main.swift
//  day10
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

//throw limitincreaseerror.ineligible


var obj1 = requestlimitincrease()
// try obj1.increaselimit(accountno: "S1100")  //if we are not sure that method create an error write it with try

var processrquest = requestlimitincrease()
/*
do{
    try processrquest.increaselimit(accountno: "S1100")
}catch is limitincreaseerror{
    print("something wrong with your account"); // if we don't want to run each error individually
}
 */
    

 do{
 try processrquest.increaselimit(accountno: "S1400")
 }catch limitincreaseerror.insuffucientbalance{
    print("you don't have sufficient balance")
}catch limitincreaseerror.ineligible {
    print("you don't have account with us")
}catch limitincreaseerror.nosavingaccount{
    print("limit increase is only available to saving account")
 }catch limitincreaseerror.processapproved {
    print("your status is already approved")
 }
 
 catch{
    print("unexpected error")
}
