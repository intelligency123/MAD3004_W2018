//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var name = String()
name = "kamal"
print(name)
let countname = name.count
print(countname)
print ("print name")
for i in 0..<countname{
    print((name[ name.index(name.startIndex , offsetBy : i)]))
}
print("print reverse name")
for i in 1...countname{
    print(name[name.index(name.endIndex , offsetBy : -i)])
}
